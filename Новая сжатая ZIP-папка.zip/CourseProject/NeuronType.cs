﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CourseProject
{
    
        public enum NeuronType
        {
            Input = 0,
            Normal = 1,
            Output = 2
        }
    
}
